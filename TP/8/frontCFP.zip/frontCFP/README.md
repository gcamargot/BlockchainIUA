# How to run the CFP WebApp
1. In terminal run "npm install"
2. In terminal run "npm run dev"
3. Use any explorer to open the url "127.0.0.1:5173"
4. Click in any of the calls to interact


